# HorizonsEye - Advanced Security Reconnaissance Toolkit

[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Tor Supported](https://img.shields.io/badge/Tor-Supported-red.svg)](https://www.torproject.org)

## 🌟 Features Overview
- **URL Scanning**: Deep analysis of single URLs (status, headers, redirects, resources)
- **Subdomain Enumeration**: Discover hidden subdomains (DNS brute + certificate scanning)
- **Directory Fuzzing**: Find hidden paths and endpoints (like dirsearch/ffuf)
- **Cloudflare Bypass**: Advanced techniques to reveal real IPs behind Cloudflare
- **Threat Intelligence**: IP reputation scoring and geolocation
- **Vulnerability Scanning**: Detect known CVEs (2020-2024) and weak endpoints
- **Form Intelligence**: Auto-detect login forms and brute-force vectors
- **TOR Anonymity**: Full SOCKS5 proxy support for anonymous scanning
- **Auto Log Management**: Encrypted, rotating logs with weekly purge

## ⚡ Quick Start

### Installation
```bash
git clone https://github.com/yourusername/HorizonsEye.git
cd HorizonsEye
pip install -r requirements.txt

# Single URL scan
python main.py https://example.com --url

# Full domain reconnaissance
python main.py example.com --full

# IP geolocation and threat analysis
python main.py 8.8.8.8 --locate --json

# Anonymous scanning with TOR
python main.py https://example.com --fuzz --admin --tor

network:
  timeout: 10  # Request timeout in seconds
  threads: 50   # Default thread count

geolocation:
  abuseipdb_key: YOUR_KEY_HERE   # AbuseIPDB API key
  securitytrails_key: YOUR_KEY   # SecurityTrails API key

tor:
  enabled: false
  port: 9050

logging:
  verbose: false
  retention_days: 7

git pull origin main
pip install --upgrade -r requirements.txt

- Only scan targets you have explicit permission to test!
+ Add --tor for anonymous scanning

# Module not found error:
pip install -r requirements.txt

# TOR connection issues:
sudo service tor start

# Outdated wordlists:
git pull origin main

#View Log
tail -f logs/horizonseye.log
