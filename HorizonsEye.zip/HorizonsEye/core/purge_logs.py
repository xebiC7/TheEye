import os
import time
from datetime import datetime, timedelta

def purge_old_logs(log_dir="logs", retention_days=7):
    now = datetime.now()
    cutoff = now - timedelta(days=retention_days)
    
    for filename in os.listdir(log_dir):
        filepath = os.path.join(log_dir, filename)
        if os.path.isfile(filepath):
            file_time = datetime.fromtimestamp(os.path.getmtime(filepath))
            if file_time < cutoff:
                os.remove(filepath)

