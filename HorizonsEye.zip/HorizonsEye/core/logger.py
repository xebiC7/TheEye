import logging
import os
import sys
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from cryptography.fernet import Fernet
import json
import gzip
import shutil
from datetime import datetime


class EncryptedRotatingHandler(RotatingFileHandler):
    def __init__(self, filename, key, max_bytes=5*1024*1024, backup_count=7):
        self.encryption_key = key
        super().__init__(filename, maxBytes=max_bytes, backupCount=backup_count)
        
    def encrypt_log(self, data):
        fernet = Fernet(self.encryption_key)
        return fernet.encrypt(data.encode())
    
    def doRollover(self):
        super().doRollover()
        if self.backupCount > 0:
            for i in range(self.backupCount, 0, -1):
                sfn = f"{self.baseFilename}.{i}"
                if os.path.exists(sfn):
                    with open(sfn, 'rb') as f:
                        data = f.read()
                    encrypted = self.encrypt_log(data.decode())
                    with open(f"{sfn}.enc", 'wb') as f:
                        f.write(encrypted)
                    os.remove(sfn)

def setup_logger(verbose=False, silent=False, log_dir="logs", log_level="INFO"):
    logger = logging.getLogger("HorizonsEye")
    
    if logger.hasHandlers():
        logger.handlers.clear()
    
    level = getattr(logging, log_level.upper(), logging.INFO)
    logger.setLevel(level)
    
    os.makedirs(log_dir, exist_ok=True)
    
    key_path = os.path.join(log_dir, "log_key.key")
    if not os.path.exists(key_path):
        key = Fernet.generate_key()
        with open(key_path, 'wb') as key_file:
            key_file.write(key)
    else:
        with open(key_path, 'rb') as key_file:
            key = key_file.read()
    
    log_file = os.path.join(log_dir, "horizonseye.log")
    file_handler = EncryptedRotatingHandler(
        filename=log_file,
        key=key,
        max_bytes=10*1024*1024,
        backup_count=7
    )
    
    log_format = '%(asctime)s | %(levelname)-8s | %(module)-15s | %(message)s'
    formatter = logging.Formatter(log_format, datefmt='%Y-%m-%d %H:%M:%S')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    if not silent:
        console_handler = logging.StreamHandler(sys.stdout)
        console_format = logging.Formatter('%(levelname)-8s | %(message)s')
        console_handler.setFormatter(console_format)
        console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
        logger.addHandler(console_handler)
    
    json_handler = TimedRotatingFileHandler(
        os.path.join(log_dir, "horizonseye.json"),
        when='midnight',
        backupCount=7
    )
    json_handler.setFormatter(JsonFormatter())
    json_handler.setLevel(logging.INFO)
    logger.addHandler(json_handler)
    
    return logger

class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'module': record.module,
            'message': record.getMessage(),
            'thread': record.thread,
            'threadName': record.threadName,
        }
        if record.exc_info:
            log_record['exception'] = self.formatException(record.exc_info)
        return json.dumps(log_record)

def compress_logs(log_dir="logs", retention_days=7):
    now = datetime.now()
    for filename in os.listdir(log_dir):
        if filename.endswith(('.log', '.json')):
            filepath = os.path.join(log_dir, filename)
            file_time = datetime.fromtimestamp(os.path.getmtime(filepath))
            age = (now - file_time).days
            if age > retention_days and not filename.endswith('.gz'):
                with open(filepath, 'rb') as f_in:
                    with gzip.open(f"{filepath}.gz", 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
                os.remove(filepath)
