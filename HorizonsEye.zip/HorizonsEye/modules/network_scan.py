import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor
from core.logger import setup_logger

logger = setup_logger()

def port_scan(target, ports, use_tor=False, timeout=1.0):
    open_ports = []
    
    def scan_port(port):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((target, port))
        sock.close()
        if result == 0:
            open_ports.append(port)
            logger.info(f"Port {port} is open")
    
    with ThreadPoolExecutor(max_workers=100) as executor:
        executor.map(scan_port, ports)
    
    return open_ports

def ping_sweep(network_prefix, start=1, end=254):
    active_hosts = []
    
    def ping_host(ip):
        try:
            subprocess.check_output(['ping', '-c', '1', '-W', '1', ip], stderr=subprocess.STDOUT)
            active_hosts.append(ip)
            logger.info(f"Active host: {ip}")
        except:
            pass
    
    with ThreadPoolExecutor(max_workers=50) as executor:
        for i in range(start, end+1):
            ip = f"{network_prefix}.{i}"
            executor.submit(ping_host, ip)
    
    return active_hosts

