# modules/admin_finder.py
import os
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from core.utils import create_session
from core.logger import setup_logger

logger = setup_logger()

def find_admin_panels(base_url, wordlist_path=None, use_tor=False):
    """Find admin panels with default wordlist handling"""
    found = []
    
    # Set default wordlist path
    if not wordlist_path:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        wordlist_path = os.path.join(base_dir, 'config', 'wordlists', 'admin_panels.txt')
    
    try:
        with open(wordlist_path) as f:
            admin_paths = [line.strip() for line in f]
    except FileNotFoundError:
        logger.error(f"Admin panel wordlist not found at {wordlist_path}")
        return found
    
    session = create_session(use_tor)
    
    for path in admin_paths:
        target_url = urljoin(base_url, path)
        try:
            response = session.get(target_url, timeout=10)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                title = soup.title.string.lower() if soup.title else ""
                
                # Check for admin indicators
                if any(indicator in title for indicator in ['admin', 'login', 'dashboard', 'control']):
                    found.append(target_url)
                    logger.info(f"Found admin panel: {target_url}")
        except Exception as e:
            logger.debug(f"Error checking {target_url}: {str(e)}")
    
    return found
