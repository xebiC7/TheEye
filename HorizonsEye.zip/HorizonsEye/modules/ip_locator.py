import requests
import json
import socket
import re
import os
from ipaddress import ip_address, ip_network
from bs4 import BeautifulSoup
from core.utils import create_session
from core.logger import setup_logger
import yaml

logger = setup_logger()

# Cloudflare IP ranges
CLOUDFLARE_IPS = [
    "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22",
    "104.16.0.0/13", "104.24.0.0/14", "108.162.192.0/18",
    "131.0.72.0/22", "141.101.64.0/18", "162.158.0.0/15",
    "172.64.0.0/13", "173.245.48.0/20", "188.114.96.0/20",
    "190.93.240.0/20", "197.234.240.0/22", "198.41.128.0/17"
]

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
    try:
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    except Exception as e:
        logger.error(f"Config load error: {str(e)}")
        return {}

def is_cloudflare_ip(ip):
    try:
        ip_addr = ip_address(ip)
        for cidr in CLOUDFLARE_IPS:
            if ip_addr in ip_network(cidr):
                return True
    except ValueError:
        pass
    return False

def get_real_ip(domain, use_tor=False):
    session = create_session(use_tor)
    config = load_config()
    securitytrails_key = config.get('geolocation', {}).get('securitytrails_key', '')
    
    # Method 1: SecurityTrails historical DNS
    if securitytrails_key:
        try:
            headers = {'APIKEY': securitytrails_key}
            resp = session.get(
                f"https://api.securitytrails.com/v1/history/{domain}/dns/a",
                headers=headers,
                timeout=15
            )
            if resp.status_code == 200:
                data = resp.json()
                for record in data.get('records', []):
                    for value in record.get('values', []):
                        ip = value.get('ip')
                        if ip and not is_cloudflare_ip(ip):
                            return ip
        except Exception as e:
            logger.debug(f"SecurityTrails error: {str(e)}")
    
    # Method 2: Common subdomains
    try:
        common_subdomains = ['direct', 'origin', 'server', 'ns1', 'ns2', 'mail']
        for sub in common_subdomains:
            try:
                fqdn = f"{sub}.{domain}"
                ip = socket.gethostbyname(fqdn)
                if not is_cloudflare_ip(ip):
                    return ip
            except socket.gaierror:
                continue
    except Exception as e:
        logger.debug(f"Subdomain bypass error: {str(e)}")
    
    # Method 3: SSL certificate
    try:
        resp = session.get(f"https://crt.sh/?q={domain}", timeout=10)
        if resp.status_code == 200:
            cert_ips = set(re.findall(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", resp.text))
            for ip in cert_ips:
                if not is_cloudflare_ip(ip):
                    return ip
    except Exception as e:
        logger.debug(f"CRT.SH error: {str(e)}")
    
    return None

def locate_ip(target, use_tor=False):
    result = {'input': target, 'ip': None, 'is_cloudflare': False, 'real_ip': None}
    
    if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", target):
        ip_address = target
        result['ip'] = ip_address
    else:
        try:
            ip_address = socket.gethostbyname(target)
            result['ip'] = ip_address
            result['domain'] = target
        except socket.gaierror:
            result['error'] = 'Invalid domain or IP address'
            return result
    
    if is_cloudflare_ip(ip_address):
        result['is_cloudflare'] = True
        real_ip = get_real_ip(target if 'domain' in result else ip_address, use_tor)
        if real_ip:
            result['real_ip'] = real_ip
            ip_address = real_ip
    
    # Geolocation
    try:
        session = create_session(use_tor)
        response = session.get(f"http://ip-api.com/json/{ip_address}")
        if response.status_code == 200:
            data = response.json()
            if data['status'] == 'success':
                result.update({
                    'country': data.get('country'),
                    'region': data.get('regionName'),
                    'city': data.get('city'),
                    'isp': data.get('isp'),
                    'as': data.get('as')
                })
    except Exception as e:
        logger.debug(f"Geolocation error: {str(e)}")
    
    return result













































































































































import requests
import json
import socket
import re
import os
from ipaddress import ip_address, ip_network
from bs4 import BeautifulSoup
from core.utils import create_session
from core.logger import setup_logger
import yaml

logger = setup_logger()

# Cloudflare IP ranges
CLOUDFLARE_IPS = [
    "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22",
    "104.16.0.0/13", "104.24.0.0/14", "108.162.192.0/18",
    "131.0.72.0/22", "141.101.64.0/18", "162.158.0.0/15",
    "172.64.0.0/13", "173.245.48.0/20", "188.114.96.0/20",
    "190.93.240.0/20", "197.234.240.0/22", "198.41.128.0/17"
]

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'settings.yaml')
    try:
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    except Exception as e:
        logger.error(f"Config load error: {str(e)}")
        return {}

def is_cloudflare_ip(ip):
    try:
        ip_addr = ip_address(ip)
        for cidr in CLOUDFLARE_IPS:
            if ip_addr in ip_network(cidr):
                return True
    except ValueError:
        pass
    return False

def get_real_ip(domain, use_tor=False):
    session = create_session(use_tor)
    config = load_config()
    securitytrails_key = config.get('geolocation', {}).get('securitytrails_key', '')
    
    # Method 1: SecurityTrails historical DNS
    if securitytrails_key:
        try:
            headers = {'APIKEY': securitytrails_key}
            resp = session.get(
                f"https://api.securitytrails.com/v1/history/{domain}/dns/a",
                headers=headers,
                timeout=15
            )
            if resp.status_code == 200:
                data = resp.json()
                for record in data.get('records', []):
                    for value in record.get('values', []):
                        ip = value.get('ip')
                        if ip and not is_cloudflare_ip(ip):
                            return ip
        except Exception as e:
            logger.debug(f"SecurityTrails error: {str(e)}")
    
    # Method 2: Common subdomains
    try:
        common_subdomains = ['direct', 'origin', 'server', 'ns1', 'ns2', 'mail']
        for sub in common_subdomains:
            try:
                fqdn = f"{sub}.{domain}"
                ip = socket.gethostbyname(fqdn)
                if not is_cloudflare_ip(ip):
                    return ip
            except socket.gaierror:
                continue
    except Exception as e:
        logger.debug(f"Subdomain bypass error: {str(e)}")
    
    # Method 3: SSL certificate
    try:
        resp = session.get(f"https://crt.sh/?q={domain}", timeout=10)
        if resp.status_code == 200:
            cert_ips = set(re.findall(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", resp.text))
            for ip in cert_ips:
                if not is_cloudflare_ip(ip):
                    return ip
    except Exception as e:
        logger.debug(f"CRT.SH error: {str(e)}")
    
    return None

def locate_ip(target, use_tor=False):
    result = {'input': target, 'ip': None, 'is_cloudflare': False, 'real_ip': None}
    
    if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", target):
        ip_address = target
        result['ip'] = ip_address
    else:
        try:
            ip_address = socket.gethostbyname(target)
            result['ip'] = ip_address
            result['domain'] = target
        except socket.gaierror:
            result['error'] = 'Invalid domain or IP address'
            return result
    
    if is_cloudflare_ip(ip_address):
        result['is_cloudflare'] = True
        real_ip = get_real_ip(target if 'domain' in result else ip_address, use_tor)
        if real_ip:
            result['real_ip'] = real_ip
            ip_address = real_ip
    
    # Geolocation
    try:
        session = create_session(use_tor)
        response = session.get(f"http://ip-api.com/json/{ip_address}")
        if response.status_code == 200:
            data = response.json()
            if data['status'] == 'success':
                result.update({
                    'country': data.get('country'),
                    'region': data.get('regionName'),
                    'city': data.get('city'),
                    'isp': data.get('isp'),
                    'as': data.get('as')
                })
    except Exception as e:
        logger.debug(f"Geolocation error: {str(e)}")
    






























































