import dns.resolver
from concurrent.futures import ThreadPoolExecutor
from core.utils import create_session

def enumerate_subdomains(domain, wordlist_path="config/wordlists/subdomains.txt", threads=50):
    found = []
    try:
        with open(wordlist_path) as f:
            subdomains = [line.strip() + '.' + domain for line in f]
    except FileNotFoundError:
        return ["Wordlist not found"]
    
    def check_subdomain(subdomain):
        try:
            dns.resolver.resolve(subdomain, 'A')
            found.append(subdomain)
        except:
            pass
    
    with ThreadPoolExecutor(max_workers=threads) as executor:
        executor.map(check_subdomain, subdomains)
    
    return found
