import requests
from concurrent.futures import ThreadPoolExecutor
from core.utils import create_session
from core.logger import setup_logger

logger = setup_logger()

def fuzz_directories(base_url, wordlist_path="config/wordlists/directories.txt", use_tor=False, threads=50, status_codes=[200, 301, 302, 403]):
    session = create_session(use_tor)
    found_dirs = []
    
    try:
        with open(wordlist_path) as f:
            directories = [line.strip() for line in f]
    except FileNotFoundError:
        logger.error(f"Directory wordlist not found at {wordlist_path}")
        return found_dirs
    
    def check_directory(path):
        target_url = f"{base_url.rstrip('/')}/{path}"
        try:
            response = session.get(target_url, timeout=5)
            if response.status_code in status_codes:
                found_dirs.append({
                    'url': target_url,
                    'status': response.status_code,
                    'size': len(response.content)
                })
                logger.info(f"Found: {target_url} [{response.status_code}]")
        except Exception as e:
            logger.debug(f"Error checking {target_url}: {str(e)}")
    
    with ThreadPoolExecutor(max_workers=threads) as executor:
        executor.map(check_directory, directories)
    
    return found_dirs
