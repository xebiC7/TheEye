from bs4 import BeautifulSoup
from core.logger import setup_logger

logger = setup_logger()

def analyze_forms(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    forms = []
    
    for form in soup.find_all('form'):
        form_info = {
            'action': form.get('action', ''),
            'method': form.get('method', 'get').lower(),
            'inputs': [],
            'vulnerabilities': []
        }
        
        # Collect input fields
        for input_tag in form.find_all('input'):
            input_info = {
                'name': input_tag.get('name', ''),
                'type': input_tag.get('type', 'text'),
                'value': input_tag.get('value', '')
            }
            form_info['inputs'].append(input_info)
        
        # Detect potential vulnerabilities
        if form_info['method'] == 'get':
            form_info['vulnerabilities'].append('GET method exposes parameters in URL')
        
        if any(i['type'] == 'password' for i in form_info['inputs']):
            form_info['vulnerabilities'].append('Contains password field - potential brute force target')
        
        if not form_info['action']:
            form_info['vulnerabilities'].append('Missing action attribute')
        
        forms.append(form_info)
    
    return forms
