# core/cli_interface.py
import argparse

def parse_arguments():
    parser = argparse.ArgumentParser(
        description="HorizonsEye - Advanced Security Reconnaissance Toolkit",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    # Main target argument
    parser.add_argument("target", help="Target URL, IP address, or network range")
    
    # Module selection
    modules = parser.add_argument_group("Scan Modules")
    modules.add_argument("--url", action="store_true", help="Perform comprehensive URL scan")
    modules.add_argument("--subdomains", action="store_true", help="Enumerate subdomains")
    modules.add_argument("--fuzz", action="store_true", help="Directory and endpoint fuzzing")
    modules.add_argument("--admin", action="store_true", help="Find admin panels")
    modules.add_argument("--locate", action="store_true", help="IP geolocation and threat analysis")
    modules.add_argument("--ports", metavar="PORTS", help="Port scanning (e.g., 80,443 or 1-1000)")
    modules.add_argument("--ping", action="store_true", help="Network ping sweep")
    modules.add_argument("--exploits", action="store_true", help="Scan for known vulnerabilities")
    modules.add_argument("--forms", action="store_true", help="Analyze web forms")
    modules.add_argument("--brute", action="store_true", help="Brute force credentials")
    modules.add_argument("--full", action="store_true", help="Run all reconnaissance modules")
    
    # Configuration options
    config = parser.add_argument_group("Configuration")
    config.add_argument("--tor", action="store_true", help="Route all traffic through TOR proxy")
    config.add_argument("--threads", type=int, default=50, help="Number of threads (default: 50)")
    config.add_argument("--wordlist", help="Custom wordlist for fuzzing/enumeration")
    config.add_argument("--output", help="Save results to specified file/directory")
    
    # Output control
    output = parser.add_argument_group("Output Control")
    output.add_argument("-v", "--verbose", action="store_true", help="Show detailed debug information")
    output.add_argument("-q", "--quiet", action="store_true", help="Suppress all non-essential output")
    output.add_argument("--json", action="store_true", help="Output results in JSON format")
    
    # Advanced options
    advanced = parser.add_argument_group("Advanced")
    advanced.add_argument("--proxy", help="Use custom proxy (http://ip:port or socks5://ip:port)")
    advanced.add_argument("--timeout", type=int, default=10, help="Request timeout in seconds (default: 10)")
    advanced.add_argument("--retries", type=int, default=2, help="Number of retries for failed requests")
    advanced.add_argument("--rate-limit", type=int, help="Maximum requests per second")
    
    # Authentication
    auth = parser.add_argument_group("Authentication")
    auth.add_argument("-u", "--username", help="Username for authentication")
    auth.add_argument("-p", "--password", help="Password for authentication")
    auth.add_argument("--cookie", help="Session cookie for authenticated scans")
    
    return parser.parse_args()

def validate_arguments(args):
    """Validate and normalize arguments"""
    # Auto-enable modules for full scan
    if args.full:
        args.url = True
        args.subdomains = True
        args.fuzz = True
        args.admin = True
        args.locate = True
        args.exploits = True
        args.forms = True
        # Exclude destructive/network modules by default
        # args.brute = True
        # args.ping = True
    
    # Validate target format for network scans
    if any([args.ping, args.ports]) and not (
        re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(/\d{1,2})?$", args.target) or
        re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.?$", args.target)
    ):
        print("ERROR: Network scanning requires valid IP range (e.g., 192.168.1.0/24 or 10.0.0)")
        return False
    
    # Validate URL-based modules
    url_modules = [args.url, args.fuzz, args.admin, args.exploits, args.forms, args.brute]
    if any(url_modules) and not args.target.startswith(("http://", "https://")):
        print("ERROR: URL-based modules require full URL starting with http:// or https://")
        return False
    
    # Check for at least one module
    if not any([
        args.url, args.subdomains, args.fuzz, args.admin, 
        args.locate, args.ports, args.ping, args.exploits,
        args.forms, args.brute, args.full
    ]):
        print("ERROR: No scan modules selected. Use --help for options.")
        return False
    
    return True

def get_scan_config(args):
    """Convert CLI arguments to configuration dictionary"""
    return {
        'target': args.target,
        'modules': {
            'url_scan': args.url or args.full,
            'subdomain_enum': args.subdomains or args.full,
            'dir_fuzz': args.fuzz or args.full,
            'admin_find': args.admin or args.full,  # Correct key name
            'ip_locate': args.locate or args.full,
            'port_scan': args.ports is not None,
            'ping_sweep': args.ping or args.full,
            'exploit_scan': args.exploits or args.full,
            'form_analysis': args.forms or args.full,
            'brute_force': args.brute or args.full
        },
        'port_spec': args.ports,
        'network': {
            'use_tor': args.tor,
            'proxy': args.proxy,
            'threads': args.threads,
            'timeout': args.timeout,
            'retries': args.retries,
            'rate_limit': args.rate_limit
        },
        'auth': {
            'username': args.username,
            'password': args.password,
            'cookie': args.cookie
        },
        'output': {
            'path': args.output,
            'json': args.json,
            'verbose': args.verbose,
            'quiet': args.quiet
        },
        'wordlist': args.wordlist
    }
