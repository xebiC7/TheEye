#!/usr/bin/env python3
import os
import sys
import json
import threading
import argparse
from datetime import datetime
from core.logger import setup_logger
from core.purge_logs import purge_old_logs
from core.cli_interface import parse_arguments, validate_arguments, get_scan_config
from modules import (
    url_scanner,
    subdomain_enum,
    dir_fuzzer,
    admin_finder,
    ip_locator,
    exploit_toolkit,
    form_intel,
    network_scan
)
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("url", help="Target URL")
parser.add_argument("--brute", action="store_true", help="Run brute-force module")
args = parser.parse_args()

target_url = args.url


BANNER = r"""
   _____ _                                 _____          
  / ____| |                               |  __ \         
 | (___ | |__   ___  _ __   ___ _ __ ___  | |__) |_____  __
  \___ \| '_ \ / _ \| '_ \ / _ \ '__/ __| |  _  // _ \ \/ /
  ____) | | | | (_) | | | |  __/ |  \__ \ | | \ \  __/>  < 
 |_____/|_| |_|\___/|_| |_|\___|_|  |___/ |_|  \_\___/_/\_\ 
"""

def main():
    print(BANNER)
    print("[+] HorizonsEye - Advanced Security Reconnaissance Toolkit")
    print("[+] Version 1.0 | Silent Mode Activated\n")
    
    # Start log purging thread
    purge_thread = threading.Thread(target=purge_old_logs, args=("logs/", 7))
    purge_thread.daemon = True
    purge_thread.start()
    
    # Parse command line arguments
    args = parse_arguments()
    if not validate_arguments(args):
        sys.exit(1)
    
    config = get_scan_config(args)
    logger = setup_logger(
        verbose=config['output']['verbose'],
        silent=config['output']['quiet']
    )
    
    logger.info(f"Starting scan for: {config['target']}")
    logger.debug(f"Configuration: {json.dumps(config, indent=2)}")
    
    results = {}
    
    # URL Scanning
    if config['modules']['url_scan']:
        logger.info("Running URL Scanner")
        results['url_scan'] = url_scanner.scan_url(
            config['target'],
            use_tor=config['network']['use_tor'],
            timeout=config['network']['timeout']
        )
    
    # Subdomain Enumeration
    if config['modules']['subdomain_enum']:
        logger.info("Running Subdomain Enumeration")
        results['subdomains'] = subdomain_enum.enumerate_subdomains(
            config['target'],
            use_tor=config['network']['use_tor'],
            threads=config['network']['threads']
        )
    
    # Directory Fuzzing
    if config['modules']['dir_fuzz']:
        logger.info("Running Directory Fuzzer")
        results['dir_fuzz'] = dir_fuzzer.fuzz_directories(
            config['target'],
            use_tor=config['network']['use_tor'],
            threads=config['network']['threads']
        )
    
    # Admin Panel Finder
    if config['modules']['admin_find']:
        logger.info("Running Admin Panel Finder")
        results['admin_panels'] = admin_finder.find_admin_panels(
            config['target'],
            use_tor=config['network']['use_tor']
        )
    
    # IP Geolocation
    if config['modules']['ip_locate']:
        logger.info("Running IP Locator")
        results['geolocation'] = ip_locator.locate_ip(
            config['target'],
            use_tor=config['network']['use_tor']
        )
    
    # Exploit Scanning
    if config['modules']['exploit_scan']:
        logger.info("Running Exploit Scanner")
        results['exploits'] = exploit_toolkit.scan_for_exploits(
            config['target'],
            use_tor=config['network']['use_tor']
        )
    
    # Network Scanning
    if config['modules']['port_scan']:
        logger.info("Running Port Scanner")
        port_spec = config.get('port_spec', '1-1000')
        if '-' in port_spec:
            start, end = map(int, port_spec.split('-'))
            ports = list(range(start, end+1))
        else:
            ports = [int(p) for p in port_spec.split(',')]
        
        results['port_scan'] = network_scan.port_scan(
            config['target'],
            ports,
            use_tor=config['network']['use_tor']
        )
    
    # Output results
    if config['output']['path']:
        with open(config['output']['path'], 'w') as f:
            json.dump(results, f, indent=2)
        logger.info(f"Results saved to {config['output']['path']}")
    elif config['output']['json']:
        print(json.dumps(results, indent=2))
    else:
        logger.info("Scan completed successfully")

if __name__ == "__main__":
    main()
