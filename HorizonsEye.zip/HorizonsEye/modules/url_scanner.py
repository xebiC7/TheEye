from bs4 import BeautifulSoup
from urllib.parse import urljoin
from core.utils import create_session
import re

def scan_url(target_url, use_tor=False):
    results = {
        'url': target_url,
        'status': None,
        'headers': {},
        'title': '',
        'redirect_chain': [],
        'resources': {'js': [], 'css': []},
        'has_login_form': False
    }
    
    try:
        session = create_session(use_tor)
        response = session.get(target_url, allow_redirects=True)
        
        # Track redirects
        if response.history:
            results['redirect_chain'] = [resp.url for resp in response.history]
        
        results['status'] = response.status_code
        results['headers'] = dict(response.headers)
        
        # Parse HTML content
        soup = BeautifulSoup(response.text, 'html.parser')
        results['title'] = soup.title.string if soup.title else ''
        
        # Find resources
        for script in soup.find_all('script', src=True):
            results['resources']['js'].append(urljoin(target_url, script['src']))
        for link in soup.find_all('link', rel='stylesheet'):
            if link.get('href'):
                results['resources']['css'].append(urljoin(target_url, link['href']))
        
        # Detect login forms
        results['has_login_form'] = detect_login_forms(soup)
        
    except Exception as e:
        results['error'] = str(e)
    
    return results

def detect_login_forms(soup):
    for form in soup.find_all('form'):
        inputs = form.find_all('input')
        input_names = [i.get('name', '').lower() for i in inputs]
        if any(name in ['username', 'user', 'login', 'email'] for name in input_names) and \
           any(name in ['password', 'pass'] for name in input_names):
            return True
    return False
